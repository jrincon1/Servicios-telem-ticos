const express = require('express') //librerías que se instalan
const mysql = require('mysql')
const cors = require('cors')
const { json } = require('express')
const app = express() //traer y enviar datos a la DB

app.use(express.json())
app.use(cors())
//Establecemos los prámetros de conexión
const conexion = mysql.createConnection({ //datos para realizar la conexión a la DB
    host: 'localhost',
    user: 'sqluser',
    password: 'password',
    database: 'tienda'
})
//Conexión a la database
conexion.connect(function(error){
    if(error){
        throw error
    }else{
        console.log("¡Conexión exitosa a la base de datos!")
    }
})
app.get('/', function(req,res){
    res.send('Ruta INICIO')
})
//Mostrar Peliculas
app.get('/api/peliculas', (req,res)=>{
    conexion.query('SELECT * FROM peliculas', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas)
        }
    })
})
//Mostrar Copias
app.get('/api/copias', (req,res)=>{
    conexion.query('SELECT * FROM copias', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas)
        }
    })
})
//Mostrar Prestamos
app.get('/api/prestamos', (req,res)=>{
    conexion.query('SELECT * FROM prestamos', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas)
        }
    })
})
//Mostrar Clientes
app.get('/api/clientes', (req,res)=>{
    conexion.query('SELECT * FROM clientes', (error,filas)=>{
        if(error){
            throw error
        }else{
            res.send(filas)
        }
    })
})
//Mostrar una SOLA Pelicula
app.get('/api/peliculas/:id_pelicula', (req,res)=>{
    conexion.query('SELECT * FROM peliculas WHERE id_pelicula = ?', [req.params.id_pelicula], (error, fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila)
        }
    })
})
//Mostrar una SOLA Copia
app.get('/api/copias/:n_copia', (req,res)=>{
    conexion.query('SELECT * FROM copias WHERE n_copia = ?', [req.params.n_copia], (error, fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila)
        }
    })
})
//Mostrar un SOLO Cliente
app.get('/api/clientes/:n_cliente', (req,res)=>{
    conexion.query('SELECT * FROM clientes WHERE cod_cliente = ?', [req.params.cod_cliente], (error, fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila)
        }
    })
})
//Mostrar un SOLO Prestamo
app.get('/api/prestamos/:n_prestamo', (req,res)=>{
    conexion.query('SELECT * FROM prestamos WHERE id_prestamo = ?', [req.params.id_prestamo], (error, fila)=>{
        if(error){
            throw error
        }else{
            res.send(fila)
        }
    })
})
//Crear una pelicula
app.post('/api/peliculas', (req,res)=>{
    let data = {titulo:req.body.titulo, anio:req.body.anio, critica:req.body.critica}
    let sql = "INSERT INTO peliculas SET ?"
    conexion.query(sql, data, function(err, result){
            if(err){
               throw err
            }else{              
             /*Esto es lo nuevo que agregamos para el CRUD con Javascript*/
             Object.assign(data, {id_pelicula: result.insertId }) //agregamos el ID al objeto data             
             res.send(data) //enviamos los valores                         
        }
    })
})
//Crear una copia
app.post('/api/copias', (req,res)=>{
    let data = {deteriorada:req.body.deteriorada, formato:req.body.formato, precio_alquiler:req.body.precio_alquiler}
    let sql = "INSERT INTO copias SET ?"
    conexion.query(sql, data, function(err, result){
            if(err){
               throw err
            }else{              
             /*Esto es lo nuevo que agregamos para el CRUD con Javascript*/
             Object.assign(data, {n_copia: result.insertId }) //agregamos el ID al objeto data             
             res.send(data) //enviamos los valores                         
        }
    })
})
//Crear un prestamo
app.post('/api/prestamos', (req,res)=>{
    let data = {fecha_prestamo:req.body.fecha_prestamo, fecha_tope:req.body.fecha_tope, fecha_entrega:req.body.fecha_entrega}
    let sql = "INSERT INTO prestamos SET ?"
    conexion.query(sql, data, function(err, result){
            if(err){
               throw err
            }else{              
             /*Esto es lo nuevo que agregamos para el CRUD con Javascript*/
             Object.assign(data, {id_prestamo: result.insertId }) //agregamos el ID al objeto data             
             res.send(data) //enviamos los valores                         
        }
    })
})
//Crear un CLIENTE
app.post('/api/clientes', (req,res)=>{
    let data = {dni:req.body.dni, nombre:req.body.nombre, apellido1:req.body.apellido1, apellido2:req.body.apellido2, direccion:req.body.direccion, email:req.body.email}
    let sql = "INSERT INTO clientes SET ?"
    conexion.query(sql, data, function(err, result){
            if(err){
               throw err
            }else{              
             /*Esto es lo nuevo que agregamos para el CRUD con Javascript*/
             Object.assign(data, {cod_cliente: result.insertId }) //agregamos el ID al objeto data             
             res.send(data) //enviamos los valores                         
        }
    })
})
//Editar pelicula
app.put('/api/peliculas/:id_pelicula', (req, res)=>{
    let id_pelicula = req.params.id_pelicula
    let titulo = req.body.titulo
    let anio = req.body.anio
    let critica = req.body.critica
    let sql = "UPDATE peliculas SET titulo = ?, anio = ?, critica = ? WHERE id_pelicula = ?"
    conexion.query(sql, [titulo, anio, critica, id_pelicula], function(error, results){
        if(error){
            throw error
        }else{              
            res.send(results)
        }
    })
})
//Editar copia
app.put('/api/copias/:n_copia', (req, res)=>{
    let n_copia = req.params.n_copia
    let deteriorada = req.body.deteriorada
    let formato = req.body.formato
    let precio_alquiler = req.body.precio_alquiler
    let sql = "UPDATE copias SET deteriorada = ?, formato = ?, precio_alquiler = ? WHERE n_copia = ?"
    conexion.query(sql, [deteriorada, formato, precio_alquiler, n_copia], function(error, results){
        if(error){
            throw error
        }else{              
            res.send(results)
        }
    })
})
//Eliminar pelicula
app.delete('/api/peliculas/:id_pelicula', (req,res)=>{
    conexion.query('DELETE FROM peliculas WHERE id_pelicula = ?', [req.params.id_pelicula], function(error, filas){
        if(error){
            throw error
        }else{              
            res.send(filas)
        }
    })
})
//Eliminar copia
app.delete('/api/copias/:n_copia', (req,res)=>{
    conexion.query('DELETE FROM copias WHERE n_copia = ?', [req.params.n_copia], function(error, filas){
        if(error){
            throw error
        }else{              
            res.send(filas)
        }
    })
})
//Eliminar cliente
app.delete('/api/clientes/:cod_cliente', (req,res)=>{
    conexion.query('DELETE FROM clientes WHERE cod_cliente = ?', [req.params.cod_cliente], function(error, filas){
        if(error){
            throw error
        }else{              
            res.send(filas)
        }
    })
})
const puerto = process.env.PUERTO || 3000 //conexión a la DB
app.listen(puerto, function(){
    console.log("Servidor Ok en puerto:"+puerto)
})