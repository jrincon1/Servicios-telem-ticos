//Definición de Variables Peliculas
const url = 'http://localhost:3000/api/peliculas/'
const contenedor = document.querySelector('tbody')
let resultados = ''

const modalPelicula = new bootstrap.Modal(document.getElementById('modalPelicula'))
const formPeliculas = document.getElementById('formPeliculas')
const titulo = document.getElementById('titulo')
const anio = document.getElementById('anio')
const critica = document.getElementById('critica')
const caratula = document.getElementById('caratula')
let opcion = ''

btnCrear.addEventListener('click',()=>{
    titulo.value = ''
    anio.value = ''
    critica.value = ''
    //caratula.value = ''
    modalPelicula.show()
    opcion = 'crear'
})
//Función 
const mostrar =(peliculas) => {
    peliculas.forEach(pelicula => {
        resultados += ` <tr>
                            <td>${pelicula.id_pelicula}</td>
                            <td>${pelicula.titulo}</td>
                            <td>${pelicula.anio}</td>
                            <td>${pelicula.critica}</td>
                            <td>${pelicula.caratula}</td>
                            <td class="text-center"><a class="btnEditar btn btn-primary">Editar</a><a class="btnBorrar btn btn-danger">Borrar</a></td>
                        </tr>
                    `
    });
    contenedor.innerHTML = resultados
}
//Mostrar
fetch(url)
    .then( response => response.json())
    .then( dataPeliculas => mostrar(dataPeliculas))
    .catch (error => console.log(error))

const on = (element, event, selector, handler) => {
    element.addEventListener(event, e=>{
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}
//Delete
on(document, 'click', '.btnBorrar', e=> {
    const fila = e.target.parentNode.parentNode
    const id_pelicula = fila.firstElementChild.innerHTML
    alertify.confirm("¿Desea eliminar la película?",
  function(){
    fetch(url+id_pelicula, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(()=>location.reload())
    //alertify.success('Ok')
  },
  function(){
    alertify.error('Cancelar')
  })
})
//Update
let idForm = 0
on(document, 'click', '.btnEditar', e=> {
    const fila = e.target.parentNode.parentNode
    idForm = fila.children[0].innerHTML
    const tituloForm = fila.children[1].innerHTML
    const anioForm = fila.children[2].innerHTML
    const criticaForm = fila.children[3].innerHTML
    //const caratulaForm = fila.children[4].innerHTML
    //console.log(`ID ${idForm}- TITULO: ${tituloForm}- AÑO: ${anioForm}- CRITICA: ${criticaForm}- CARATULA: ${caratulaForm}`)
    titulo.value = tituloForm
    anio.value = anioForm
    critica.value = criticaForm
    //caratula.value = caratulaForm
    opcion = 'editar'
    modalPelicula.show()        
})
//Create or Update
formPeliculas.addEventListener('submit', (e)=>{
    e.preventDefault()
    if(opcion=='crear'){
        //console.log('OPCION CREAR')
        fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                titulo:titulo.value,
                anio:anio.value,
                critica:critica.value
                //caratula:caratula.value
            })
        })
        .then( response => response.json())
        .then (dataPeliculas => {
            const nuevaPelicula =[]
            nuevaPelicula.push(dataPeliculas)
            mostrar(nuevaPelicula)
        })
    }
    if(opcion=='editar'){
        //console.log('OPCION EDITAR')
        fetch(url+idForm,{
            method: 'PUT',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                titulo:titulo.value,
                anio:anio.value,
                critica:critica.value
                //caratula:caratula.value
            })
        })
        .then(response => response.json())
        .then(response => location.reload())
    }
    modalPelicula.hide()
})
//Definición de Variables Copias
const url_copia = 'http://localhost:3000/api/copias/' 
const contenedor_copia = document.getElementById('tbodycopias')
let resultados_copia = ''

const modalCopia = new bootstrap.Modal(document.getElementById('modalCopia'))
const formCopias = document.getElementById('formCopias')
const deteriorada = document.getElementById('deteriorada')
const formato = document.getElementById('formato')
const precio_alquiler = document.getElementById('precio_alquiler')
let opcion_copia = ''

btnCrearCopias.addEventListener('click',()=>{
    deteriorada.value = null
    formato.value = ''
    precio_alquiler.value = ''
    modalCopia.show()
    opcion_copia = 'crear'
})
//Función 
const mostrar_copia =(copias) => {
    copias.forEach(copia => {
        resultados_copia += ` <tr>
                            <td>${copia.n_copia}</td>
                            <td>${copia.id_pelicula}</td>
                            <td>${copia.deteriorada}</td>
                            <td>${copia.formato}</td>                            
                            <td>${copia.precio_alquiler}</td>
                            <td class="text-center"><a class="btnEditarCopias btn btn-primary">Editar</a><a class="btnBorrarCopias btn btn-danger">Borrar</a></td>
                        </tr>
                    `
    });
    contenedor_copia.innerHTML = resultados_copia
}
//Mostrar
fetch(url_copia)
    .then( response => response.json())
    .then( dataCopias => mostrar_copia(dataCopias))
    .catch (error => console.log(error))

const on_copia = (element, event, selector, handler) => {
    element.addEventListener(event, e=>{
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}
//Delete
on_copia(document, 'click', '.btnBorrarCopias', e=> {
    const fila_copia = e.target.parentNode.parentNode
    const n_copia = fila_copia.firstElementChild.innerHTML
    alertify.confirm("¿Desea eliminar la información?",
  function(){
    fetch(url_copia+n_copia, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(()=>location.reload())
    //alertify.success('Ok')
  },
  function(){
    alertify.error('Cancelar')
  })
})
//Update
let idForm_copia = 0
on_copia(document, 'click', '.btnEditarCopias', e=> {
    const fila_copia = e.target.parentNode.parentNode
    idForm_copia = fila_copia.children[0].innerHTML
    const deterioradaForm = fila_copia.children[1].innerHTML
    const formatoForm = fila_copia.children[2].innerHTML
    const precio_alquilerForm = fila_copia.children[3].innerHTML
    //const caratulaForm = fila.children[4].innerHTML
    //console.log(`ID ${idForm}- TITULO: ${tituloForm}- AÑO: ${anioForm}- CRITICA: ${criticaForm}- CARATULA: ${caratulaForm}`)
    deteriorada.value = deterioradaForm
    formato.value = formatoForm
    precio_alquiler.value = precio_alquilerForm
    //caratula.value = caratulaForm
    opcion_copia = 'editar'
    modalCopia.show()        
})
//Create or Update
formCopias.addEventListener('submit', (e)=>{
    e.preventDefault()
    if(opcion_copia=='crear'){
        //console.log('OPCION CREAR')
        fetch(url_copia,{
            method: 'POST',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                deteriorada:deteriorada.value,
                formato:formato.value,
                precio_alquiler:precio_alquiler.value
                
            })
        })
        .then( response => response.json())
        .then (dataCopias => {
            const nuevaCopia =[]
            nuevaCopia.push(dataCopias)
            mostrar_copia(nuevaCopia)
        })
    }
    if(opcion_copia=='editar'){
        //console.log('OPCION EDITAR')
        fetch(url_copia+idForm_copia,{
            method: 'PUT',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                deteriorada:deteriorada.value,
                formato:formato.value,
                precio_alquiler:precio_alquiler.value
                
            })
        })
        .then(response => response.json())
        .then(response => location.reload())
    }
    modalCopia.hide()
})
//Definición de Variables Clientes
const url_cliente = 'http://localhost:3000/api/clientes/' 
const contenedor_cliente = document.getElementById('tbodyclientes')
let resultados_cliente = ''

const modalCliente = new bootstrap.Modal(document.getElementById('modalCliente'))
const formClientes = document.getElementById('formClientes')
const dni = document.getElementById('dni')
const nombre = document.getElementById('nombre')
const apellido1 = document.getElementById('apellido1')
const apellido2 = document.getElementById('apellido2')
const direccion = document.getElementById('direccion')
const email = document.getElementById('email')
let opcion_cliente = ''

btnCrearClientes.addEventListener('click',()=>{
    dni.value = ''
    nombre.value = ''
    apellido1.value = ''
    apellido2.value = ''
    direccion.value = ''
    email.value = ''
    modalCliente.show()
    opcion_cliente = 'crear'
})
//Función 
const mostrar_cliente =(clientes) => {
    clientes.forEach(cliente => {
        resultados_cliente += ` <tr>
                            <td>${cliente.cod_cliente}</td>
                            <td>${cliente.dni}</td>
                            <td>${cliente.nombre}</td>
                            <td>${cliente.apellido1}</td>
                            <td>${cliente.apellido2}</td>
                            <td>${cliente.direccion}</td>
                            <td>${cliente.email}</td>
                           
                            
                            <td class="text-center"><a class="btnEditarClientes btn btn-primary">Editar</a><a class="btnBorrarClientes btn btn-danger">Borrar</a></td>
                        </tr>
                    `
    });
    contenedor_cliente.innerHTML = resultados_cliente
}
//Mostrar
fetch(url_cliente)
    .then( response => response.json())
    .then( dataClientes => mostrar_cliente(dataClientes))
    .catch (error => console.log(error))

const on_cliente = (element, event, selector, handler) => {
    element.addEventListener(event, e=>{
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}
//Delete
on_cliente(document, 'click', '.btnBorrarClientes', e=> {
    const fila_cliente = e.target.parentNode.parentNode
    const cod_cliente = fila_cliente.firstElementChild.innerHTML
    alertify.confirm("¿Desea eliminar la información del cliente?",
  function(){
    fetch(url_cliente+cod_cliente, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(()=>location.reload())
    //alertify.success('Ok')
  },
  function(){
    alertify.error('Cancelar')
  })
})
//Update
let idForm_cliente = 0
on_cliente(document, 'click', '.btnEditarClientes', e=> {
    const fila_cliente = e.target.parentNode.parentNode
    idForm_cliente = fila_cliente.children[0].innerHTML
    const dniForm = fila_cliente.children[1].innerHTML
    const nombreForm = fila_cliente.children[2].innerHTML
    const apellido1Form = fila_cliente.children[3].innerHTML
    const apellido2Form = fila_cliente.children[4].innerHTML
    const direccionForm = fila_cliente.children[5].innerHTML
    const emailForm = fila_cliente.children[6].innerHTML
    dni.value = dniForm
    nombre.value = nombreForm
    apellido1.value = apellido1Form
    apellido2.value = apellido2Form
    direccion.value = direccionForm
    email.value = emailForm
    
    opcion_cliente = 'editar'
    modalCliente.show()        
})
//Create or Update
formClientes.addEventListener('submit', (e)=>{
    e.preventDefault()
    if(opcion_cliente=='crear'){
        //console.log('OPCION CREAR')
        fetch(url_cliente, {
            method: 'POST',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                dni:dni.value,
                nombre:nombre.value,
                apellido1:apellido1.value,
                apellido2:apellido2.value,
                direccion:direccion.value,
                email:email.value
            })
        })
        .then( response => response.json())
        .then (dataClientes => {
            const nuevoCliente =[]
            nuevoCliente.push(dataClientes)
            mostrar_cliente(nuevoCliente)
        })
    }
    if(opcion_cliente=='editar'){
        //console.log('OPCION EDITAR')
        fetch(url_cliente+idForm_cliente,{
            method: 'PUT',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                dni:dni.value,
                nombre:nombre.value,
                apellido1:apellido1.value,
                apellido2:apellido2.value,
                direccion:direccion.value,
                email:email.value
            })
        })
        .then(response => response.json())
        .then(response => location.reload())
    }
    modalCliente.hide()
})
//Definición de Variables Prestamos
const url_prestamo = 'http://localhost:3000/api/prestamos/' 
const contenedor_prestamo = document.getElementById('tbodyprestamos')
let resultados_prestamo = ''

const modalPrestamo = new bootstrap.Modal(document.getElementById('modalPrestamo'))
const formPrestamos = document.getElementById('formPrestamos')
const fecha_prestamo = document.getElementById('fecha_prestamo')
const fecha_tope = document.getElementById('fecha_tope')
const fecha_entrega = document.getElementById('fecha_entrega')
let opcion_prestamo = ''

btnCrearPrestamos.addEventListener('click',()=>{
    fecha_prestamo.value = ''
    fecha_tope.value = ''
    fecha_entrega.value = ''
    //caratula.value = ''
    modalPrestamo.show()
    opcion_prestamo = 'crear'
})
//Función 
const mostrar_prestamo =(prestamos) => {
    prestamos.forEach(prestamo => {
        resultados_prestamo += ` <tr>
                            <td>${prestamo.id_prestamo}</td>
                            <td>${prestamo.fecha_prestamo}</td>
                            <td>${prestamo.fecha_tope}</td>
                            <td>${prestamo.fecha_entrega}</td>
                            <td>${prestamo.cod_cliente}</td>
                            <td>${prestamo.n_copia}</td>                          
                            <td class="text-center"><a class="btnEditarPrestamos btn btn-primary">Editar</a><a class="btnBorrarPrestamos btn btn-danger">Borrar</a></td>
                        </tr>
                    `
    });
    contenedor_prestamo.innerHTML = resultados_prestamo
}
//Mostrar
fetch(url_prestamo)
    .then( response => response.json())
    .then( dataPrestamos => mostrar_prestamo(dataPrestamos))
    .catch (error => console.log(error))

const on_prestamo = (element, event, selector, handler) => {
    element.addEventListener(event, e=>{
        if(e.target.closest(selector)){
            handler(e)
        }
    })
}
//Delete
on_prestamo(document, 'click', '.btnBorrarPrestamos', e=> {
    const fila_prestamo = e.target.parentNode.parentNode
    const id_prestamo = fila_prestamo.firstElementChild.innerHTML
    alertify.confirm("¿Desea eliminar la información del préstamo?",
  function(){
    fetch(url_prestamo+id_prestamo, {
        method: 'DELETE'
    })
    .then(res => res.json())
    .then(()=>location.reload())
    //alertify.success('Ok')
  },
  function(){
    alertify.error('Cancelar')
  })
})
//Update
let idForm_prestamo = 0
on_prestamo(document, 'click', '.btnEditarPrestamos', e=> {
    const fila_prestamo = e.target.parentNode.parentNode
    idForm_prestamo = fila_prestamo.children[0].innerHTML
    const fecha_prestamoForm = fila_prestamo.children[1].innerHTML
    const fecha_topeForm = fila_prestamo.children[2].innerHTML
    const fecha_entregaForm = fila_prestamo.children[3].innerHTML
    //const caratulaForm = fila.children[4].innerHTML
    //console.log(`ID ${idForm}- TITULO: ${tituloForm}- AÑO: ${anioForm}- CRITICA: ${criticaForm}- CARATULA: ${caratulaForm}`)
    fecha_prestamo.value = fecha_prestamoForm
    fecha_tope.value = fecha_topeForm
    fecha_entrega.value = fecha_entregaForm
    //caratula.value = caratulaForm
    opcion_prestamo = 'editar'
    modalPrestamo.show()        
})
//Create or Update
formPrestamos.addEventListener('submit', (e)=>{
    e.preventDefault()
    if(opcion_prestamo=='crear'){
        //console.log('OPCION CREAR')
        fetch(url_prestamo, {
            method: 'POST',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                fecha_prestamo:fecha_prestamo.value,
                fecha_tope:fecha_tope.value,
                fecha_entrega:fecha_entrega.value
                
            })
        })
        .then( response => response.json())
        .then (dataPrestamos => {
            const nuevoPrestamo =[]
            nuevoPrestamo.push(dataPrestamos)
            mostrar_prestamo(nuevoPrestamo)
        })
    }
    if(opcion_prestamo=='editar'){
        //console.log('OPCION EDITAR')
        fetch(url_prestamo+idForm_prestamo,{
            method: 'PUT',
            headers: {
                'Content-Type':'application/json'
            },
            body: JSON.stringify({
                fecha_prestamo:fecha_prestamo.value,
                fecha_tope:fecha_tope.value,
                fecha_entrega:fecha_entrega.value
                
            })
        })
        .then(response => response.json())
        .then(response => location.reload())
    }
    modalPrestamo.hide()
})